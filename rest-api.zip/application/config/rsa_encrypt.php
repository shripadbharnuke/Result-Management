<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
|  RSA Encrypt Configuration.
|--------------------------------------------------------------------------|
*/
$config['PRIVATE_KEY']	= 'certs/headlines-app-content-priv.pem';
$config['PUBLIC_KEY'] 	= 'certs/headlines-app-content-pub.pem';
$config['PRIVATE_PASSPHRASE'] 	= '3C0Uvr4pI2';

/* End of file rsa_encrypt.php */
/* Location: ./application/config/rsa_encrypt.php */
