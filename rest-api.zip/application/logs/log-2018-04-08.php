ERROR - 2018-04-08 14:31:40 --> 404 Page Not Found: ../modules/api/controllers//index
ERROR - 2018-04-08 14:36:30 --> Login - Details ------------
ERROR - 2018-04-08 14:38:38 --> Login - Details admin@admin.com------------admin
ERROR - 2018-04-08 14:40:24 --> Login - Details admin@admin.com------------admin
ERROR - 2018-04-08 14:41:41 --> Login - Details admin@admin.com------------admin
ERROR - 2018-04-08 14:54:55 --> 404 Page Not Found: ../modules/api/controllers//index
ERROR - 2018-04-08 14:56:45 --> Login - Details admin@admin.com------------admin
ERROR - 2018-04-08 14:57:45 --> Login - Details admin@admin.com------------admin
ERROR - 2018-04-08 14:59:28 --> Login - Details admin@admin.com------------admin
ERROR - 2018-04-08 15:01:20 --> Logout API End for user id. 
ERROR - 2018-04-08 15:01:33 --> Logout API End for user id. 
ERROR - 2018-04-08 15:01:44 --> Logout API End for user id. 
ERROR - 2018-04-08 15:28:35 --> Login - Details admin@admin.com------------admin
ERROR - 2018-04-08 16:03:49 --> Login - Details admin@admin.com------------admin
ERROR - 2018-04-08 16:09:25 --> Severity: Notice --> Undefined variable: group D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 18
ERROR - 2018-04-08 16:09:25 --> Severity: Notice --> Undefined variable: group D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 19
ERROR - 2018-04-08 16:09:57 --> Severity: Notice --> Undefined variable: group D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 18
ERROR - 2018-04-08 16:09:57 --> Severity: Notice --> Undefined variable: group D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 19
ERROR - 2018-04-08 16:10:39 --> Severity: Notice --> Undefined property: Student::$user_role_id D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 18
ERROR - 2018-04-08 16:10:39 --> Severity: Notice --> Undefined variable: group D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 19
ERROR - 2018-04-08 16:10:51 --> Severity: Notice --> Undefined property: Student::$user_role_id D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 18
ERROR - 2018-04-08 16:11:08 --> Severity: Notice --> Undefined property: Student::$user_role_id D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 18
ERROR - 2018-04-08 16:12:23 --> Severity: Notice --> Undefined variable: group D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 25
ERROR - 2018-04-08 16:14:42 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 27
ERROR - 2018-04-08 16:20:44 --> Severity: Notice --> Undefined property: Student::$ion_auth D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 17
ERROR - 2018-04-08 16:20:44 --> Severity: Error --> Call to a member function get_user_id() on null D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 17
ERROR - 2018-04-08 16:22:35 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 20
ERROR - 2018-04-08 16:22:56 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 20
ERROR - 2018-04-08 16:24:16 --> Login - Details john@admin.com------------password
ERROR - 2018-04-08 16:24:34 --> Severity: Notice --> Undefined variable: userId D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 20
ERROR - 2018-04-08 16:24:45 --> Severity: Notice --> Undefined variable: userId D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 20
ERROR - 2018-04-08 16:25:32 --> Login - Details john@admin.com------------password
ERROR - 2018-04-08 16:25:55 --> Severity: Notice --> Undefined variable: userId D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 20
ERROR - 2018-04-08 16:30:58 --> Login - Details admin@admin.com------------admin
ERROR - 2018-04-08 16:31:32 --> Login - Details john@admin.com------------password
ERROR - 2018-04-08 16:33:01 --> Login - Details john@admin.com------------passwor
ERROR - 2018-04-08 16:34:24 --> Login - Details john@admin.com------------passwor
ERROR - 2018-04-08 16:49:05 --> Login - Details john@admin.com------------password
ERROR - 2018-04-08 16:57:48 --> Login - Details admin@admin.com------------admin

ERROR - 2018-04-08 16:58:01 --> Login - Details admin@admin.com------------admin
ERROR - 2018-04-08 16:58:21 --> Severity: Notice --> Undefined variable: message D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 39
ERROR - 2018-04-08 16:58:21 --> Severity: Notice --> Undefined variable: status_code D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 39
ERROR - 2018-04-08 16:59:20 --> Severity: Notice --> Undefined variable: status_code D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 41
ERROR - 2018-04-08 17:48:11 --> Severity: Notice --> Undefined variable: status_code D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 50
ERROR - 2018-04-08 17:48:53 --> Login - Details admin@admin.com------------admin
ERROR - 2018-04-08 17:49:04 --> Severity: Notice --> Undefined variable: status_code D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 50
ERROR - 2018-04-08 17:49:37 --> Severity: Notice --> Undefined variable: message D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 50
ERROR - 2018-04-08 17:49:37 --> Severity: Notice --> Undefined variable: status_code D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 50
ERROR - 2018-04-08 17:50:15 --> Severity: Notice --> Undefined variable: message D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 50
ERROR - 2018-04-08 17:50:15 --> Severity: Notice --> Undefined variable: status_code D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 50
ERROR - 2018-04-08 17:50:20 --> Severity: Notice --> Undefined variable: status_code D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 50
ERROR - 2018-04-08 17:51:03 --> Severity: Notice --> Undefined variable: status_code D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 51
ERROR - 2018-04-08 17:51:26 --> Severity: Notice --> Undefined variable: status_code D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 51
ERROR - 2018-04-08 17:51:36 --> Severity: Notice --> Undefined variable: status_code D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 51
ERROR - 2018-04-08 17:51:38 --> Severity: Notice --> Undefined variable: status_code D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 51
ERROR - 2018-04-08 17:53:00 --> Severity: Notice --> Undefined variable: status_code D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 51
ERROR - 2018-04-08 17:53:31 --> Severity: Notice --> Undefined variable: status_code D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 52
ERROR - 2018-04-08 17:54:46 --> Severity: Notice --> Undefined variable: status_code D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 54
ERROR - 2018-04-08 18:01:39 --> Severity: Notice --> Undefined variable: status_code D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 53
ERROR - 2018-04-08 18:13:08 --> Severity: Parsing Error --> syntax error, unexpected ''sciencemarks'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 45
ERROR - 2018-04-08 18:13:26 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) D:\xampp\htdocs\rest-api\application\modules\api\models\Students_m.php 88
ERROR - 2018-04-08 18:21:47 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\rest-api\application\modules\api\models\Students_m.php 100
ERROR - 2018-04-08 18:32:44 --> Severity: Notice --> Undefined index: math_marks D:\xampp\htdocs\rest-api\application\modules\api\models\Students_m.php 95
ERROR - 2018-04-08 18:32:44 --> Query error: Column 'math_marks' cannot be null - Invalid query: INSERT INTO `marks` (`user_id`, `math_marks`, `science_marks`, `english_marks`) VALUES (6, NULL, '28', '55')
ERROR - 2018-04-08 18:41:11 --> Severity: Notice --> Undefined variable: status_code D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 62
ERROR - 2018-04-08 19:05:15 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) D:\xampp\htdocs\rest-api\application\modules\api\models\Students_m.php 110
ERROR - 2018-04-08 19:05:33 --> Severity: Notice --> Undefined variable: status_code D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 112
ERROR - 2018-04-08 19:06:01 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::row_array() D:\xampp\htdocs\rest-api\application\modules\api\models\Students_m.php 110
ERROR - 2018-04-08 19:10:24 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::num_rows() D:\xampp\htdocs\rest-api\application\modules\api\models\Students_m.php 110
ERROR - 2018-04-08 19:10:51 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) D:\xampp\htdocs\rest-api\application\modules\api\models\Students_m.php 110
ERROR - 2018-04-08 19:10:59 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) D:\xampp\htdocs\rest-api\application\modules\api\models\Students_m.php 110
ERROR - 2018-04-08 19:11:14 --> Severity: Parsing Error --> syntax error, unexpected '=' D:\xampp\htdocs\rest-api\application\modules\api\models\Students_m.php 110
ERROR - 2018-04-08 19:13:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE `id` = '111'' at line 2 - Invalid query: SELECT `id`
WHERE `id` = '111'
ERROR - 2018-04-08 19:18:57 --> Query error: Table 'restapiserver.id' doesn't exist - Invalid query: SELECT `id`
FROM `student_info`, `id`
WHERE 100 IS NULL
ERROR - 2018-04-08 19:20:55 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::result_array() D:\xampp\htdocs\rest-api\application\modules\api\models\Students_m.php 110
ERROR - 2018-04-08 19:21:22 --> Severity: Parsing Error --> syntax error, unexpected ';' D:\xampp\htdocs\rest-api\application\modules\api\models\Students_m.php 111
ERROR - 2018-04-08 19:21:56 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::get() D:\xampp\htdocs\rest-api\application\modules\api\models\Students_m.php 111
ERROR - 2018-04-08 19:24:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '* = '101'' at line 3 - Invalid query: SELECT *
FROM `student_info`
WHERE * = '101'
ERROR - 2018-04-08 19:24:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '* = '101'' at line 3 - Invalid query: SELECT *
FROM `student_info`
WHERE * = '101'
ERROR - 2018-04-08 19:27:47 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\rest-api\application\modules\api\models\Students_m.php 112
ERROR - 2018-04-08 20:04:44 --> Severity: Notice --> Use of undefined constant trueq - assumed 'trueq' D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 120
ERROR - 2018-04-08 20:09:48 --> Query error: Table 'restapiserver.student_id' doesn't exist - Invalid query: SELECT *
FROM `student_info`
JOIN `student_id` ON `student_info`.`id` = `marks`.`user_id`
WHERE `id` = '10'
ERROR - 2018-04-08 20:11:06 --> Query error: Column 'id' in where clause is ambiguous - Invalid query: SELECT *
FROM `student_info`
JOIN `marks` ON `student_info`.`id` = `marks`.`user_id`
WHERE `id` = '10'
ERROR - 2018-04-08 20:11:38 --> Query error: Column 'id' in where clause is ambiguous - Invalid query: SELECT *
FROM `student_info`
JOIN `marks` ON `marks`.`user_id` = `student_info`.`id`
WHERE `id` = '10'
ERROR - 2018-04-08 20:20:29 --> Severity: Parsing Error --> syntax error, unexpected 'exit' (T_EXIT) D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 120
ERROR - 2018-04-08 20:21:07 --> Severity: Notice --> Undefined variable: allstudents D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 127
ERROR - 2018-04-08 20:26:52 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 121
ERROR - 2018-04-08 20:53:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 121
ERROR - 2018-04-08 20:53:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 122
ERROR - 2018-04-08 20:53:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 123
ERROR - 2018-04-08 21:21:00 --> Severity: Warning --> rsort() expects parameter 1 to be array, null given D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 125
ERROR - 2018-04-08 21:21:00 --> Severity: Warning --> rsort() expects parameter 1 to be array, null given D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 125
ERROR - 2018-04-08 21:21:00 --> Severity: Warning --> rsort() expects parameter 1 to be array, null given D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 125
ERROR - 2018-04-08 21:55:36 --> Severity: Compile Error --> Can't use function return value in write context D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 125
ERROR - 2018-04-08 21:56:39 --> Severity: Compile Error --> Can't use function return value in write context D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 125
ERROR - 2018-04-08 21:56:47 --> Severity: Compile Error --> Can't use function return value in write context D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 125
ERROR - 2018-04-08 21:57:08 --> Severity: Compile Error --> Can't use function return value in write context D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 125
ERROR - 2018-04-08 21:57:16 --> Severity: Compile Error --> Can't use function return value in write context D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 125
ERROR - 2018-04-08 22:05:48 --> Severity: Notice --> Undefined variable: id D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 134
ERROR - 2018-04-08 22:33:38 --> Severity: Notice --> Undefined variable: id D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 134
ERROR - 2018-04-08 22:33:56 --> Severity: Notice --> Undefined variable: id D:\xampp\htdocs\rest-api\application\modules\api\controllers\Student.php 134
